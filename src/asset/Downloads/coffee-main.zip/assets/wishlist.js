;(function (Wishlist, $) {
    var $wishlistBtn = $('.wishremove');
    var $wishlistCart = $('.cart');
    var $wishcount = $('.wishcount');
    var numProductTiles = $wishlistCart.length;
    var wishlist = localStorage.getItem('wishtems') || [];
    var wishcountall = localStorage.getItem('wishtemscount');

    $wishcount.html(wishcountall == null ? 0 : wishcountall);

    if (wishlist.length > 0) {
        wishlist = JSON.parse(localStorage.getItem('wishtems'));
    }
    var animateWishlist = function (e) {
        $(e).toggleClass('wishactive');
    };
    var updateWishlist = function (self) {
        var productHandle = $(self).attr('data-product-handle');
        var isRemove = $(self).hasClass('wishactive');
        //var wishcountvalue = localStorage.getItem('wishtemscount');
        if (isRemove) {
            var removeIndex = wishlist.indexOf(productHandle);
                wishlist.splice(removeIndex, 1);
            var wishcountp = localStorage.getItem('wishtemscount');
            if(wishcountp != null){
                var minus_val = -1;
                var wish_ct = Math.max(parseInt(wishcountp) + minus_val, 0);
                localStorage.setItem('wishtemscount', wish_ct);
            }
            localStorage.setItem('wishtems', JSON.stringify(wishlist));
            //var icon_length = $(self).find("span").length;
            if($(self).find("span").length != 0){
                $wishlistBtn.html('<span class="addtowish"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.37767 2.11365C6.16662 2.31401 5.83338 2.31401 5.62233 2.11365L5.24466 1.75511C4.8026 1.33544 4.20542 1.0792 3.54545 1.0792C2.18985 1.0792 1.09091 2.16634 1.09091 3.5074C1.09091 4.79307 1.79443 5.85469 2.81005 6.72696C3.82654 7.59997 5.04185 8.17897 5.76799 8.47446C5.91982 8.53625 6.08018 8.53625 6.23201 8.47446C6.95814 8.17897 8.17346 7.59997 9.18995 6.72696C10.2056 5.85469 10.9091 4.79307 10.9091 3.5074C10.9091 2.16634 9.81015 1.0792 8.45455 1.0792C7.79458 1.0792 7.1974 1.33544 6.75535 1.75511L6.37767 2.11365ZM6 0.976447C5.36297 0.371679 4.49809 0 3.54545 0C1.58735 0 0 1.57032 0 3.5074C0 6.94372 3.80201 8.84136 5.35298 9.47252C5.77067 9.6425 6.22933 9.64249 6.64702 9.47252C8.198 8.84136 12 6.94371 12 3.5074C12 1.57032 10.4126 0 8.45455 0C7.50191 0 6.63703 0.371679 6 0.976447Z" fill="white"></path></svg></span>');
            }
            //var wishcountp_value = localStorage.getItem('wishtemscount');
            $wishcount.html(localStorage.getItem('wishtemscount'));
        }
        else {
            wishlist.push(productHandle);
            var wishcountp = localStorage.getItem('wishtemscount');
            if(wishcountp == null){
                var plus_val = 1;
                var wish_ct = plus_val;
            }else{
            var plus_val = 1;
            var wish_ct = Math.max(parseInt(wishcountp) + plus_val, 0);
        }
            localStorage.setItem('wishtemscount',wish_ct);
            localStorage.setItem('wishtems', JSON.stringify(wishlist));
            var icon_length = $(self).find("span").length;
            if(icon_length != 0){
                $wishlistBtn.html('<span class="addtowish"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.37767 2.11365C6.16662 2.31401 5.83338 2.31401 5.62233 2.11365L5.24466 1.75511C4.8026 1.33544 4.20542 1.0792 3.54545 1.0792C2.18985 1.0792 1.09091 2.16634 1.09091 3.5074C1.09091 4.79307 1.79443 5.85469 2.81005 6.72696C3.82654 7.59997 5.04185 8.17897 5.76799 8.47446C5.91982 8.53625 6.08018 8.53625 6.23201 8.47446C6.95814 8.17897 8.17346 7.59997 9.18995 6.72696C10.2056 5.85469 10.9091 4.79307 10.9091 3.5074C10.9091 2.16634 9.81015 1.0792 8.45455 1.0792C7.79458 1.0792 7.1974 1.33544 6.75535 1.75511L6.37767 2.11365ZM6 0.976447C5.36297 0.371679 4.49809 0 3.54545 0C1.58735 0 0 1.57032 0 3.5074C0 6.94372 3.80201 8.84136 5.35298 9.47252C5.77067 9.6425 6.22933 9.64249 6.64702 9.47252C8.198 8.84136 12 6.94371 12 3.5074C12 1.57032 10.4126 0 8.45455 0C7.50191 0 6.63703 0.371679 6 0.976447Z" fill="white"></path></svg></span>');
            }
            var wishcountp_value = localStorage.getItem('wishtemscount');
            $wishcount.html(wishcountp_value);
        }
    };
    var activateWishItems = function () {
        $wishlistBtn.each(function () {
        var productHandle = $(this).attr('data-product-handle');
            if (wishlist.indexOf(productHandle) > -1) {
                $(this).addClass('wishactive');
                var icon_length = $(this).find("span").length;
                if($(this).hasClass('wishactive')){
                    if(icon_length != 0){
                        $(this).html('<span class="addtowish"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.37767 2.11365C6.16662 2.31401 5.83338 2.31401 5.62233 2.11365L5.24466 1.75511C4.8026 1.33544 4.20542 1.0792 3.54545 1.0792C2.18985 1.0792 1.09091 2.16634 1.09091 3.5074C1.09091 4.79307 1.79443 5.85469 2.81005 6.72696C3.82654 7.59997 5.04185 8.17897 5.76799 8.47446C5.91982 8.53625 6.08018 8.53625 6.23201 8.47446C6.95814 8.17897 8.17346 7.59997 9.18995 6.72696C10.2056 5.85469 10.9091 4.79307 10.9091 3.5074C10.9091 2.16634 9.81015 1.0792 8.45455 1.0792C7.79458 1.0792 7.1974 1.33544 6.75535 1.75511L6.37767 2.11365ZM6 0.976447C5.36297 0.371679 4.49809 0 3.54545 0C1.58735 0 0 1.57032 0 3.5074C0 6.94372 3.80201 8.84136 5.35298 9.47252C5.77067 9.6425 6.22933 9.64249 6.64702 9.47252C8.198 8.84136 12 6.94371 12 3.5074C12 1.57032 10.4126 0 8.45455 0C7.50191 0 6.63703 0.371679 6 0.976447Z" fill="white"></path></svg></span>');
                    }
                }else{
                    if(icon_length != 0){
                        $(this).html('<span class="addtowish"><svg xmlns="http://www.w3.org/2000/svg" width="12" height="10" viewBox="0 0 12 10" fill="none"><path fill-rule="evenodd" clip-rule="evenodd" d="M6.37767 2.11365C6.16662 2.31401 5.83338 2.31401 5.62233 2.11365L5.24466 1.75511C4.8026 1.33544 4.20542 1.0792 3.54545 1.0792C2.18985 1.0792 1.09091 2.16634 1.09091 3.5074C1.09091 4.79307 1.79443 5.85469 2.81005 6.72696C3.82654 7.59997 5.04185 8.17897 5.76799 8.47446C5.91982 8.53625 6.08018 8.53625 6.23201 8.47446C6.95814 8.17897 8.17346 7.59997 9.18995 6.72696C10.2056 5.85469 10.9091 4.79307 10.9091 3.5074C10.9091 2.16634 9.81015 1.0792 8.45455 1.0792C7.79458 1.0792 7.1974 1.33544 6.75535 1.75511L6.37767 2.11365ZM6 0.976447C5.36297 0.371679 4.49809 0 3.54545 0C1.58735 0 0 1.57032 0 3.5074C0 6.94372 3.80201 8.84136 5.35298 9.47252C5.77067 9.6425 6.22933 9.64249 6.64702 9.47252C8.198 8.84136 12 6.94371 12 3.5074C12 1.57032 10.4126 0 8.45455 0C7.50191 0 6.63703 0.371679 6 0.976447Z" fill="white"></path></svg></span>');
                    }
                }
            }
        });
    };
    var displayWishItems = function () {
        $wishlistCart.each(function () {
        var productHandle = $(this).attr('data-product-handle');
            if (wishlist.indexOf(productHandle) === -1) {
                $(this).remove();
                numProductTiles--;
            }
        });
    };
    var loadWishlist = function () {
        if (window.location.href.indexOf('pages/wishlist') > -1) {
        displayWishItems();
            $('.wishloader').fadeOut(2000, function () {
                $('.mainwish .wishlist-hero').addClass('wishvisible');
                //$('.wishlist-hero').addClass('wishvisible');
                if (numProductTiles == 0) {
                    $('.wishempty').addClass('wishvisible');
                    $('.mainwish').hide();
                } else {
                    $('.wishempty').hide();
                }
            });
        }
    };
    var bindUIActions = function () {
        $wishlistBtn.click(function (e) {
            e.preventDefault();
            updateWishlist(this);
            animateWishlist(this);
        });
    };
    Wishlist.init = function () {
        bindUIActions();
        activateWishItems();
        loadWishlist();
    };
    $("#wishcall").click(function(){
        //var raw = localStorage.getItem('wishtems');
        //var length = raw.length;
        var length = localStorage.getItem('wishtems').length;
        //var i;
        var productHandle = $(self).attr('data-product-handle');
        var isRemove = $(self).hasClass('wishactive');
        for ( var i=length-1; i>= 0; i--){
        var removeIndex = wishlist.indexOf(productHandle);
        wishlist.splice(removeIndex, 1);
        var wishcountp = localStorage.getItem('wishtemscount');
            if(wishcountp != null){
                var wish_ct = Math.max(parseInt(0), 0);
                localStorage.setItem('wishtemscount', wish_ct);
            }
            localStorage.setItem('wishtems', JSON.stringify(wishlist));
        }
        location.reload(true);
    });
}(window.Wishlist = window.Wishlist || {}, jQuery, undefined));
function reloadPage(){
    location.reload(true);
}